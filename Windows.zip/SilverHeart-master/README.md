# SilverHeart
A software fully developed in [Python 3.7.3](https://www.python.org/), *SilverHeart* is a keylogger concept, that can be deployed in Windows, Mac OS and Linux distributions.


# Dependencies
- [Pywin32](https://pypi.org/project/pywin32/)
- [pynput](https://pypi.org/project/pynput/)

# Getting Started


![*Building*](https://i.gifer.com/3jnq.gif)
